package com.common.helper;

import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.common.R;
import com.common.ui.BaseActivity;


/**
 * Created by MUSHAHID on 9/30/2015
 */
public class AppDialogs {

    private BaseActivity activity;


    public AppDialogs(BaseActivity acc) {
        activity=acc;

    }



    public void showToast(int StringResourceId) {
        showToast(activity.getString(StringResourceId));
    }

    public void showToast(String message) {
        Toast toast = Toast.makeText(activity, message, Toast.LENGTH_SHORT);
        toast.show();
    }


    /**
     * Dialogs for No Internet
     */
    public void showNoInternetDailog() {
        showAlertDialog(activity.getResources().getString(R.string.NetworkError)
                , activity.getResources().getString(R.string.no_internet)
                , activity.getResources().getString(R.string.str_Ok)
                , false, null);
    }

    public void showNoInternetDailog(OnOkClickListner OnOkclick) {
        showAlertDialog(activity.getResources().getString(R.string.NetworkError)
                , activity.getResources().getString(R.string.no_internet)
                , activity.getResources().getString(R.string.str_Ok)
                , false, OnOkclick);
    }


    /**
     * Dialogs for WebServiceAlert
     *
     * @param Message
     */
    public void showErrorAlertDialog(String Message) {
        showAlertDialog(activity.getResources().getString(R.string.Error)
                , Message
                , activity.getResources().getString(R.string.str_Ok)
                , false, null);
    }

    public void showErrorAlertDialog(String Message, OnOkClickListner OnOkClick) {
        showAlertDialog(activity.getResources().getString(R.string.Error)
                , Message
                , activity.getResources().getString(R.string.str_Ok)
                , false, OnOkClick);
    }


    /**
     * Dialogs for Normal Alert
     *
     * @param TitleTextResourseId
     * @param Message
     * @param ButtonTextResourseId
     * @param ShouldClose
     */

    public void showAlertDialog(int TitleTextResourseId, String Message, int ButtonTextResourseId,
                                final boolean ShouldClose) {
        showAlertDialog(activity.getResources().getString(TitleTextResourseId)
                , Message
                , activity.getResources().getString(ButtonTextResourseId)
                , ShouldClose, null);
    }

    public void showAlertDialog(int TitleTextResourseId, String Message, int ButtonTextResourseId,
                                final boolean ShouldClose, final OnOkClickListner OnOkclick) {
        showAlertDialog(activity.getResources().getString(TitleTextResourseId)
                , Message
                , activity.getResources().getString(ButtonTextResourseId)
                , ShouldClose, OnOkclick);
    }


    public void showAlertDialog(int TitleTextResourseId, String Message, int ButtonTextResourseId) {
        showAlertDialog(activity.getResources().getString(TitleTextResourseId)
                , Message
                , activity.getResources().getString(ButtonTextResourseId)
                , false, null);
    }

    public void showAlertDialog(String Title, String Message, String ButtonText) {
        showAlertDialog(Title
                , Message
                , ButtonText
                , false, null);
    }

    public void showAlertDialog(String Title, String Message, String ButtonText,
                                final boolean ShouldClose, final OnOkClickListner OnOkclick) {
        AlertDialog alertDialog;
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
        // set title
        alertDialogBuilder.setTitle(Title);
        // set dialog message
        alertDialogBuilder.setMessage(Message);
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(ButtonText, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (ShouldClose) {
                    activity.onBackPressed();
                } else {
                    if (OnOkclick != null) {
                        OnOkclick.OnOkClick();
                    }
                }
                dialog.dismiss();
            }
        });
        // create alert dialog
        alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }




    public void showAlertDialogWithOptions(String Title, String Message, String PositiveText,
                                           String NegativeButtonText, final OnMultipleButtonClickListener
                                                   OnMulticlick) {
        AlertDialog alertDialog;
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
        // set title
        alertDialogBuilder.setTitle(Title);
        // set dialog message
        alertDialogBuilder.setMessage(Message);
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(PositiveText, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
                if (OnMulticlick != null) {
                    OnMulticlick.OnPositiveClick();
                }
            }
        });

        alertDialogBuilder.setNegativeButton(NegativeButtonText, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // if this button is clicked, just close
                // the dialog box and do nothing
                dialog.dismiss();
                if (OnMulticlick != null) {
                    OnMulticlick.OnNegativeClick();
                }
            }
        });

        // create alert dialog
        alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    public void showSnackBarForLong(View view, String message) {
        Snackbar snackbar = Snackbar.make(view, message, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text); //Get reference of snackbar textview
        textView.setMaxLines(3); // Change your max lines
        snackbarView.setBackgroundColor(ContextCompat.getColor(view.getContext(), R.color.colorPrimaryDark));
        snackbar.show();
    }


    public void showSnackBar(View view, String message) {
        Snackbar snackbar = Snackbar.make(view, message, Snackbar.LENGTH_SHORT);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(view.getContext(), R.color.colorPrimaryDark));
        snackbar.show();
    }


    public interface OnOkClickListner {
        void OnOkClick();
    }

    public interface OnMultipleButtonClickListener {
        void OnPositiveClick();

        void OnNegativeClick();
    }

}

