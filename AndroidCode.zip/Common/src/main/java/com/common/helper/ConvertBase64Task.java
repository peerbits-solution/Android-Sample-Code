package com.common.helper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.util.Log;

import com.common.ui.BaseActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class ConvertBase64Task extends AsyncTask<Void, Bitmap, Bitmap> {

    private ByteArrayOutputStream baos = new ByteArrayOutputStream();

    private int CompressionRatio = 80; //You can change it by what ever ratio you want. in 0 to 100.

    private boolean shouldrotate = true;

    private BaseActivity mF;

    private String url;

    byte[] imagebyte;

    private ImageCompressiorListner imageCompressiorListner;

    public ConvertBase64Task(String url,BaseActivity activity) {
        mF = activity;
        this.url = url;
    }

    public void setRotation(boolean isRotate) {
        shouldrotate = isRotate;
    }


    public void setCompressionRatio(int Ratio) {
        CompressionRatio = Ratio;
    }


    public void setImageCompressiorListner(ImageCompressiorListner imageCompressiorListner) {
        this.imageCompressiorListner = imageCompressiorListner;
    }

    @Override
    protected void onPreExecute() {
        mF.showProgress();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        if (url != null && url.length() > 0) {

            Log.e("Path", "" + url);
            try {
                //***** Fatching file
                File f = new File(url);
                //*****Code for Orientation
                Matrix matrix = new Matrix();

                if (shouldrotate) {
                    ExifInterface exif1 = new ExifInterface(f.getAbsolutePath());
                    int orientation = exif1.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, 1);
                    Log.d("EXIF", "Exif: " + orientation);
                    if (orientation == 6) {
                        matrix.postRotate(90);
                    } else if (orientation == 3) {
                        matrix.postRotate(180);
                    } else if (orientation == 8) {
                        matrix.postRotate(270);
                    } else {
                        matrix.postRotate(0);
                    }
                } else {
                    matrix.postRotate(0);
                }

                try {

                    BitmapFactory.Options option = new BitmapFactory.Options();
                    option.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getAbsolutePath(), option);

                    int file_size = Integer.parseInt(String.valueOf(f.length() / 1024));
                    Log.e("ImageSize", "" + file_size);


                    int scale = 1;

                    if (file_size < 512) {
                        Log.e("image size is good", "image size is less");
                    } else if (file_size < 1024) {
                        Log.e("image size is 1 mb", "image size is heavy");
                        scale = 2;
                    } else if (file_size < 1536) {
                        Log.e("image size is 1.5 mb", "image size is heavy");
                        scale = 2;
                    } else if (file_size < 2048) {
                        Log.e("image size is 2 mb", "image size is heavy");
                        scale = 4;
                    } else {
                        Log.e("image size > 2 mb", "image size is heavy");
                        scale = 4;
                    }

                    Log.e("Scale", "Finaly Scaling with " + scale);

                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = scale;
                    Bitmap pickimg = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);

                    if (pickimg.getWidth() > 1280 || pickimg.getHeight() > 1000) {

                        int width = pickimg.getWidth();
                        int height = pickimg.getHeight();

                        while (width > 1280 || height > 700) {
                            width = (width * 90) / 100;
                            height = (height * 90) / 100;
                        }

                        pickimg = Bitmap.createScaledBitmap(pickimg, width, height, true);
                    } else {
                        pickimg = Bitmap.createBitmap(pickimg, 0, 0, pickimg.getWidth(), pickimg.getHeight(), matrix, true); // rotating bitmap
                    }

                    pickimg.compress(Bitmap.CompressFormat.JPEG, CompressionRatio, baos);
                    imagebyte = baos.toByteArray();
                    return pickimg;

                } catch (OutOfMemoryError e) {
                    e.printStackTrace();
                    return null;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;

                }

            } catch (Throwable e) {
                e.printStackTrace();
                return null;
            }

        } else {

            return null;
        }
    }

    @Override
    protected void onPostExecute(Bitmap result) {
        super.onPostExecute(result);
        mF.stopProgress();
        if (result != null) {
            if(imageCompressiorListner!=null){
                imageCompressiorListner.onImageCompressed(result,imagebyte);
            }

        } else {
            if(imageCompressiorListner!=null){
                imageCompressiorListner.onError();
            }
        }
    }


    public interface ImageCompressiorListner {
        void onImageCompressed(Bitmap bitmap,byte[] byteArray);
        void onError();
    }
}
