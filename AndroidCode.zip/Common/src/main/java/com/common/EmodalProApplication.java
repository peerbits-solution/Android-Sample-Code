package com.common;

import android.support.multidex.MultiDexApplication;

/**
 * Created by Charanjeet on 23-03-2017.
 */

public class EmodalProApplication extends MultiDexApplication {


    @Override
    public void onCreate() {
        super.onCreate();
    }


}
