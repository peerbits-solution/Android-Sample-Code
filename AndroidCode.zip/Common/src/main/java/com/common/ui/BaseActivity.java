package com.common.ui;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.common.helper.AppDialogs;
import com.common.utils.MyProgressDialog;
import com.common.utils.SessionManager;

public class BaseActivity extends AppCompatActivity {

    boolean shouldPerformDispatchTouch = true;
    protected SessionManager session;

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    // Progress
    private MyProgressDialog progressDialog;

    // CommonDailogs
    protected AppDialogs mDailogs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new SessionManager(this);
        mDailogs = new AppDialogs(this);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View view = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);


        if (shouldPerformDispatchTouch) {
            if (view instanceof EditText) {
                try {
                    View w = getCurrentFocus();
                    int scrcords[] = new int[2];
                    w.getLocationOnScreen(scrcords);
                    float x = event.getRawX() + w.getLeft() - scrcords[0];
                    float y = event.getRawY() + w.getTop() - scrcords[1];

                    if (event.getAction() == MotionEvent.ACTION_UP && (x < w.getLeft() || x >= w.getRight() || y < w.getTop() || y > w.getBottom())) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (getWindow() != null && getWindow().getCurrentFocus() != null) {
                            imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }


    //**** Progress Methods ******//
    public void showProgress() {
        showProgress(null);
    }

    public void showProgress(String message) {
        if (progressDialog != null) {
            progressDialog.show(message);
        } else {
            progressDialog = new MyProgressDialog(this, message);
            progressDialog.show();
        }
    }

    public void stopProgress() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    protected boolean isProgressShowing() {
        return progressDialog != null && progressDialog.isShowing();
    }

    protected boolean isConnectedToInternet() {
        ConnectivityManager connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivity.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isAvailable() && activeNetwork.isConnected();
    }
}
