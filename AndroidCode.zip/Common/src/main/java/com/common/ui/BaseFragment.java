package com.common.ui;


import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.common.helper.AppDialogs;
import com.common.utils.MyProgressDialog;
import com.common.utils.SessionManager;


public class BaseFragment extends Fragment {


    protected Context mContext;
    protected View mainView;

    public BaseActivity mActivity;

    // Progress
    private MyProgressDialog progressDialog;

    // CommonDailogs
    protected AppDialogs mDailogs;

    // Preference Handeling
    protected SessionManager session;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;

        if (context instanceof Activity) {
            mActivity = (BaseActivity) context;

        }
        mDailogs = new AppDialogs(mActivity);
        session = new SessionManager(mContext);
    }


    //**** Progress Methods ******//
    public void showProgress() {
        showProgress(null);
    }

    public void showProgress(String message) {
        if (progressDialog != null) {
            progressDialog.show(message);
        } else {
            progressDialog = new MyProgressDialog(mContext, message);
            progressDialog.show();
        }
    }

    public void stopProgress() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    protected boolean isProgressShowing() {
        return progressDialog != null && progressDialog.isShowing();
    }


    public void hideKeyBoard() {
        View view = getActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    protected boolean isConnectedToInternet() {
        ConnectivityManager connectivity = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivity.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isAvailable() && activeNetwork.isConnected();
    }
}

