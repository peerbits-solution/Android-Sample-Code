package com.common.network.listeners;


public interface RetrofitRawResponseListener {
    void onPreExecute();
    void onSuccess(int statusCode, String jsonObject);
    void onError(int statusCode, String message);
}
