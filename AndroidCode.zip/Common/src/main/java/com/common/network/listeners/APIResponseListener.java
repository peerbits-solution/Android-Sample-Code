package com.common.network.listeners;

import org.json.JSONObject;


public interface APIResponseListener {
    void onPreExecute();
    void onSuccess(int statusCode, JSONObject jsonObject);
    void onError(int statusCode, String message);
}
