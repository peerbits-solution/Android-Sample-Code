package com.common.network.listeners;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Charanjeet on 05-01-2017.
 */

public interface RetrofitPaginationResponseListener {
    void onPreExecute();
    void onSuccess(int statusCode, JSONObject jsonObject) throws JSONException;
    void onError(int statusCode, String message);
    void onCompleted();
}
