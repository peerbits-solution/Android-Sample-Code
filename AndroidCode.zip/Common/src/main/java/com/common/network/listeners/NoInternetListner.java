package com.common.network.listeners;


public interface NoInternetListner {
    void onNoInternet();
}
