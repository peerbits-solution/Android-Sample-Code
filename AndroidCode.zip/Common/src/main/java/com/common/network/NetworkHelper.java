package com.common.network;

import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Toast;

import com.common.R;
import com.common.network.listeners.APIResponseListener;
import com.common.network.listeners.NoInternetListner;
import com.common.utils.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NetworkHelper implements Callback<ResponseBody> {

    private static final String MULTIPART_FORM_DATA = "multipart/form-data";
    @SuppressWarnings("WeakerAccess")
    public static final int NO_INTERNET_PROMPT_TOAST = 0;
    @SuppressWarnings("WeakerAccess")
    public static final int NO_INTERNET_PROMPT_SNACKBAR = 1;
    @SuppressWarnings("WeakerAccess")
    public static final int NO_INTERNET_PROMPT_ALERT = 2;


    private String endPoint = "";
    private Context mContext = null;


    private boolean shouldPromptOnNoInternet = true;
    private int noInternetPromptType = NO_INTERNET_PROMPT_TOAST;
    private NoInternetListner noInternetListner = null;

    private View snackbarView = null;

    private APIResponseListener retrofitResponseListener = null;


    private Call call;

    HashMap<String,String> headers;

    public NetworkHelper(Context context, String strAPI_EndPoing) {
        this.endPoint = strAPI_EndPoing;
        this.mContext = context;
        this.headers = new HashMap<>();
    }


    public void setResponseListener(APIResponseListener retrofitRxResponseListener) {
        this.retrofitResponseListener = retrofitRxResponseListener;
    }


    public void setNoInternetPromptType(int noInternetPromptType) {
        this.noInternetPromptType = noInternetPromptType;
    }

    public void setNoInternetPromptType(int noInternetPromptType, View snackBarView) {
        this.noInternetPromptType = noInternetPromptType;
        this.snackbarView = snackBarView;
    }

    public void setShouldPromptOnNoInternet(boolean shouldPromptOnNoInternet) {
        this.shouldPromptOnNoInternet = shouldPromptOnNoInternet;
    }

    public void setNoInternetListner(NoInternetListner noInternetListner) {
        this.noInternetListner = noInternetListner;
    }

    public void setHeaders(HashMap<String, String> headers) {
        this.headers = headers;
    }

    // RxJava Code
    public void executeRequest(HashMap<String, String> requestParams) {
        executeRequest(requestParams, null);
    }

    public void executeRequest(HashMap<String, String> requestParams, HashMap<String, File> files) {

        if (isConnectedToInternet()) {
            if (files != null) {
                makeMultipartRequest(requestParams, files);
            } else {
                makeSimpleTextRequest(requestParams);
            }
        } else {
            if (shouldPromptOnNoInternet) {
                switch (noInternetPromptType) {
                    case NO_INTERNET_PROMPT_TOAST:
                        Toast.makeText(mContext, mContext.getText(R.string.no_internet), Toast.LENGTH_SHORT).show();
                        break;
                    case NO_INTERNET_PROMPT_SNACKBAR:
                        if (snackbarView != null) {
                            Snackbar.make(snackbarView, mContext.getText(R.string.no_internet), Snackbar.LENGTH_SHORT).show();
                        }
                        break;
                    case NO_INTERNET_PROMPT_ALERT:
                        showNoInternetAlert();
                        break;
                }
            }

            if (noInternetListner != null) {
                noInternetListner.onNoInternet();
            }
        }
    }




    private void makeSimpleTextRequest(HashMap<String,String> requestParams) {
        Logger.verbose("API EndPoint => " + endPoint);

        if (headers.size() > 0) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                Logger.Error(entry.getKey() + "=>" + entry.getValue());
            }
        } else {
            Logger.Error("headers are empty");
        }

        if (requestParams.size() > 0) {
            for (Map.Entry<String, String> entry : requestParams.entrySet()) {
                Logger.Error(entry.getKey() + "=>" + entry.getValue());
            }
        } else {
            Logger.Error("Param are empty");
        }

        if (retrofitResponseListener != null) {
            retrofitResponseListener.onPreExecute();
        }
        call = RetrofitApp.getInstance().APICall(endPoint, headers, requestParams);
        call.enqueue(this);
    }


    private void makeMultipartRequest(HashMap<String,String> requestParams,HashMap<String,File> files) {
        Logger.verbose("API EndPoint => " + endPoint);

        if (headers.size() > 0) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                Logger.Error(entry.getKey() + "=>" + entry.getValue());
            }
        } else {
            Logger.Error("headers are empty");
        }

        HashMap<String, RequestBody> bodyParams = new HashMap<>();

        if (requestParams.size() > 0) {
            for (Map.Entry<String, String> entry : requestParams.entrySet()) {
                Logger.Error(entry.getKey() + "=>" + entry.getValue());
                bodyParams.put(entry.getKey(), createPartFromString(entry.getValue()));
            }
        } else {
            Logger.Error("Param are empty");
        }


        if (files.size() > 0) {
            for (Map.Entry<String, File> entry : files.entrySet()) {
                Logger.Error(entry.getKey() + "=>" + entry.getValue().getPath());
                String fileName = entry.getKey() + "\"; filename=\"" + entry.getValue().getName();
                bodyParams.put(fileName, createPartFromFile(entry.getValue()));
            }
        } else {
            Logger.Error("Files are empty");
        }


        if (retrofitResponseListener != null) {
            retrofitResponseListener.onPreExecute();
        }
        call = RetrofitApp.getInstance().APICallMultipart(endPoint, headers, bodyParams);
        call.enqueue(this);
    }



    public void cancelRequest() {
        call.cancel();
    }


    @Override
    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
        handleResponse(response);
    }

    @Override
    public void onFailure(Call<ResponseBody> call, Throwable t) {
        handleError(t);
    }


    private void handleResponse(Response<ResponseBody> response) {
        try {
            if (response.body() != null) {
                String body = response.body().string();
                Logger.Error("Success" + body);
                try {
                    JSONObject object = new JSONObject(body);
                    if (retrofitResponseListener != null) {
                        retrofitResponseListener.onSuccess(response.code(), object);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    if (retrofitResponseListener != null) {
                        retrofitResponseListener.onError(response.code(), mContext.getString(R.string.str_something_went_wrong));
                    }
                }
            } else {
                String body = response.errorBody().string();
                Logger.Error("Error Body =>" + body);
                String message = mContext.getString(R.string.str_something_went_wrong);
                try {
                    JSONObject object = new JSONObject(body);
                    if (object.optString("message") != null) {
                        message = object.optString("message");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    if (retrofitResponseListener != null) {
                        retrofitResponseListener.onError(response.code(), message);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            if (retrofitResponseListener != null) {
                retrofitResponseListener.onError(response.code(), mContext.getString(R.string.str_something_went_wrong));
            }
        }
    }


    private void handleError(Throwable e) {
        e.printStackTrace();
        String errorMessage;
        if (e.getMessage() != null && e.getMessage().length() > 0) {
            errorMessage = e.getMessage();
        } else {
            errorMessage = mContext.getString(R.string.str_something_went_wrong);
        }

        if (retrofitResponseListener != null) {
            retrofitResponseListener.onError(500, errorMessage);
        }
    }


    private RequestBody createPartFromString(String value) {
        return RequestBody.create(MediaType.parse(MULTIPART_FORM_DATA), value);
    }

    private RequestBody createPartFromFile(File file) {
        return RequestBody.create(MediaType.parse(MULTIPART_FORM_DATA), file);
    }


    private boolean isConnectedToInternet() {
        ConnectivityManager connectivity = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivity.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isAvailable() && activeNetwork.isConnected();
    }

    private void showNoInternetAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle(mContext.getResources().getString(R.string.app_name));
        builder.setCancelable(true);

        builder.setMessage(mContext.getString(R.string.str_no_internet));
        builder.setPositiveButton(mContext.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.create().show();
    }
}



