package com.common.utils;

import android.content.Context;

import com.common.R;

public class SessionManager {

    private SecurePreferences pref;

    public SessionManager(Context context) {
        String PREF_NAME = context.getResources().getString(R.string.app_name);
        pref = SecurePreferences.getInstance(context, PREF_NAME);
    }


    public String getValueFromKey(String key) {
        if (pref.containsKey(key)) {
            return pref.getString(key, "");
        } else {
            return "";
        }
    }

    public String getValueFromKey(String key,String defaultValue) {
        if (pref.containsKey(key)) {
            return pref.getString(key, defaultValue);
        } else {
            return defaultValue;
        }
    }

    public void setValueForKey(String key, String value) {
        pref.putString(key, value);
    }


    public boolean getFlagFromKey(String key) {
        return pref.containsKey(key) && pref.getBoolean(key, false);
    }


    public void setFlagFromKey(String key, boolean value) {
        pref.putBoolean(key, value);
    }



    public void clearData(){
        pref.clear();
        pref.commit();
    }

}
